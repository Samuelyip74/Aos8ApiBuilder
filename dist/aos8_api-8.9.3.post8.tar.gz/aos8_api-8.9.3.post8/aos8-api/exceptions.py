# aos_api_client/exceptions.py

class AuthenticationError(Exception):
    pass
